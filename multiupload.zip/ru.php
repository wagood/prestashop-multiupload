<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multiupload}prestashop>multiupload_608795ca4d1e0593ed0e67fe0c57b47a'] = 'Мульти Загрузка Изображений';
$_MODULE['<{multiupload}prestashop>multiupload_77002201e9c5913f3847ff26f3350f67'] = 'Загрузка изображений товара по несколько штук за один раз.';
